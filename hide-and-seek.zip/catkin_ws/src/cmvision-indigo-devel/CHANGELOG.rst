^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cmvision
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.1 (2013-09-03)
------------------
* fixed missing fltk dependency. closes `#1 <https://github.com/utexas-bwi/cmvision/issues/1>`_

0.4.0 (2013-08-30)
------------------
* Ported cmvision to github from  wg-ros-pkg
* Catkinized for release into ROS Hydro
