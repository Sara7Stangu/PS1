cmvision_3d
==================

This is a package using the /blobs topic produced by cmvision, in addition to 3D data from a registered depth image, to publish both 1. the position of each color blob relative to its camera frame, and 2. frames in the tf stack for each color.

## Usage:
See http://wiki.ros.org/cmvision_3d
