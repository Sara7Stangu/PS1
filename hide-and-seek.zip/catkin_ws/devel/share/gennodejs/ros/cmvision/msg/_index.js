
"use strict";

let Blob = require('./Blob.js');
let Blobs = require('./Blobs.js');

module.exports = {
  Blob: Blob,
  Blobs: Blobs,
};
